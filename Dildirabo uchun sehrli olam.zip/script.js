/* ============================================================
   Dildirabo uchun sehrli olam — sahna boshqaruvchisi
   ============================================================ */
'use strict';

const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const $ = (id) => document.getElementById(id);

/* ---------------- Ma'lumotlar ---------------- */

const GALLERY = [
  { src: 'assets/photos/01.jpg', caption: 'Dildirabo opajon, hayotingiz doimo go‘zal lahzalar va quvonchli xotiralarga to‘la bo‘lsin!' },
  { src: 'assets/photos/02.jpg', caption: 'Yuzingizdan tabassum, qalbingizdan mehr, hayotingizdan baxt hech qachon arimasin!' },
  { src: 'assets/photos/03.jpg', caption: 'Sizga eng go‘zal kunlar, unutilmas xotiralar va cheksiz quvonch tilayman!' },
  { src: 'assets/photos/04.jpg', caption: 'Atrofingiz doimo sizni qadrlaydigan, samimiy va mehribon insonlarga to‘la bo‘lsin!' },
  { src: 'assets/photos/05.jpg', caption: 'Har bir yangi kun sizga yangi imkoniyatlar, baxt va ajoyib yangiliklar olib kelsin!' },
  { src: 'assets/photos/06.jpg', caption: 'Orzularingiz birin-ketin amalga oshsin, qalbingiz esa doimo xotirjam bo‘lsin!' },
  { src: 'assets/photos/07.jpg', caption: 'Sizga sehrli ertaklardek go‘zal lahzalar va qalbingiz istagan barcha yaxshiliklarni tilayman!' },
  { src: 'assets/photos/08.jpg', caption: 'Qalbingiz doim yorug‘, kunlaringiz esa doim yengil va yorqin bo‘lsin!' },
  { src: 'assets/photos/09.jpg', caption: 'Sizning samimiy kulgingiz atrofdagilarga ham quvonch ulashsin!' },
  { src: 'assets/photos/10.jpg', caption: 'Har doim shunday baxtli, o‘zingizga ishongan va yorqin bo‘lib qoling!' },
];
const SLIDE_MS = 5000;

const FANTASY = [
  {
    label: '✨ Yulduzlar va koinot',
    title: '✨ Yulduzlar va koinot',
    text: 'Osmon sizning orzularingiz kabi cheksiz va sehrli bo‘lsin, Dildirabo opajon!',
    images: ['assets/fantasy/galaktika-1.jpg', 'assets/fantasy/galaktika-2.jpg', 'assets/fantasy/galaktika-3.jpg'],
  },
  {
    label: '🦆 Sehrli ko‘l',
    title: '🦆 Sehrli ko‘l',
    text: 'Hayotingiz shu oqqushlar suzayotgan ko‘l kabi tinch, nafis va go‘zal bo‘lsin!',
    images: ['assets/fantasy/kol-1.jpg', 'assets/fantasy/kol-2.jpg'],
  },
  {
    label: '🌸 Gullar olami',
    title: '🌸 Gullar olami',
    text: 'Qalbingiz shu gullar kabi doimo ochilib, atrofga mehr va go‘zallik ulashib tursin!',
    images: ['assets/fantasy/gul-1.jpg', 'assets/fantasy/gul-2.jpg'],
  },
  {
    label: '🌠 Orzular olami',
    title: '🌠 Orzular olami',
    text: 'Orzularingiz sari yo‘lingiz shu manzaralardek yorqin va ilhombaxsh bo‘lsin!',
    images: ['assets/fantasy/orzu-1.jpg', 'assets/fantasy/orzu-2.jpg'],
  },
];

const FINAL_LINES = [
  'Dildirabo opajon! Sizga eng samimiy tilaklarimni yuboraman.',
  'Hayotingiz doimo mehr, quvonch, go‘zal xotiralar va yorqin imkoniyatlarga boy bo‘lsin.',
  'Har bir kuningiz o‘zgacha chiroyli, har bir orzuingiz esa amalga oshishga yaqin bo‘lsin.',
  'Doimo kulib yuring va baxtli bo‘ling! 💖',
];

/* ---------------- Yulduzli fon (canvas) ---------------- */

(function stars() {
  const canvas = $('stars');
  const ctx = canvas.getContext('2d');
  let w, h, pts;

  function resize() {
    w = canvas.width = innerWidth;
    h = canvas.height = innerHeight;
    const count = Math.min(140, Math.round((w * h) / 9000));
    pts = Array.from({ length: count }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.4 + 0.3,
      a: Math.random() * Math.PI * 2,
      speed: Math.random() * 0.015 + 0.004,
    }));
  }
  resize();
  addEventListener('resize', resize);

  function draw() {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#fff';
    for (const p of pts) {
      p.a += p.speed;
      const alpha = 0.35 + Math.sin(p.a) * 0.35;
      ctx.globalAlpha = Math.max(0.05, alpha);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  draw();
})();

/* ---------------- Sahna almashtirgich ---------------- */

const scenes = ['intro', 'video', 'gallery', 'fantasy', 'final'].reduce((o, k) => {
  o[k] = $('scene-' + k);
  return o;
}, {});

function goTo(name) {
  Object.values(scenes).forEach((s) => s.classList.remove('is-active'));
  scenes[name].classList.add('is-active');
  scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
}

/* ---------------- 1. Intro ---------------- */

$('btn-enter').addEventListener('click', () => {
  goTo('video');
  startVideo();
});

/* ---------------- 2. Video sahnasi ---------------- */

const video = $('greeting-video');
const playOverlay = $('btn-play-video');
const videoError = $('video-error');

function startVideo() {
  videoError.hidden = true;
  video.currentTime = 0;
  const p = video.play();
  if (p && p.catch) {
    p.then(() => playOverlay.classList.add('is-hidden'))
      .catch(() => playOverlay.classList.remove('is-hidden'));
  } else {
    playOverlay.classList.add('is-hidden');
  }
}

playOverlay.addEventListener('click', () => {
  video.muted = false;
  startVideo();
});

video.addEventListener('playing', () => playOverlay.classList.add('is-hidden'));

video.addEventListener('ended', () => {
  goTo('gallery');
  startGallery();
});

video.addEventListener('error', () => {
  videoError.hidden = false;
  playOverlay.classList.add('is-hidden');
});

$('btn-skip-video').addEventListener('click', () => {
  video.pause();
  goTo('gallery');
  startGallery();
});

/* ---------------- 3. Rasmlar galereyasi ---------------- */

const galleryFrame = $('gallery-frame');
const galleryCaption = $('gallery-caption');
const galleryCounter = $('g-counter');
const progressBar = $('g-progress').querySelector('span');
const pauseBtn = $('g-pause');

let gIndex = 0;
let gPaused = false;
let gTimer = null;
let gStarted = false;

GALLERY.forEach((item, i) => {
  const slide = document.createElement('div');
  slide.className = 'g-slide' + (i === 0 ? ' is-active' : '');
  const img = document.createElement('img');
  img.src = item.src;
  img.alt = 'Dildirabo opam va dugonalari bilan xotira ' + (i + 1);
  img.loading = i < 2 ? 'eager' : 'lazy';
  slide.appendChild(img);
  galleryFrame.appendChild(slide);
});
const gSlides = [...galleryFrame.children];

function renderGallery() {
  gSlides.forEach((s, i) => s.classList.toggle('is-active', i === gIndex));
  galleryCaption.textContent = GALLERY[gIndex].caption;
  galleryCounter.textContent = `${gIndex + 1} / ${GALLERY.length}`;
}

function runProgress() {
  progressBar.classList.remove('is-animating');
  progressBar.style.transitionDuration = '0ms';
  progressBar.style.width = '0%';
  // keyingi freymda animatsiyani yoqamiz
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      progressBar.classList.add('is-animating');
      progressBar.style.transitionDuration = SLIDE_MS + 'ms';
      progressBar.style.width = '100%';
    });
  });
}

function scheduleNext() {
  clearTimeout(gTimer);
  if (gPaused) return;
  runProgress();
  gTimer = setTimeout(() => {
    gIndex = (gIndex + 1) % GALLERY.length;
    renderGallery();
    scheduleNext();
  }, SLIDE_MS);
}

function gotoSlide(i) {
  gIndex = (i + GALLERY.length) % GALLERY.length;
  renderGallery();
  scheduleNext();
}

function startGallery() {
  if (gStarted) { gIndex = 0; renderGallery(); scheduleNext(); return; }
  gStarted = true;
  renderGallery();
  scheduleNext();
}

$('g-prev').addEventListener('click', () => gotoSlide(gIndex - 1));
$('g-next').addEventListener('click', () => gotoSlide(gIndex + 1));
pauseBtn.addEventListener('click', () => {
  gPaused = !gPaused;
  pauseBtn.textContent = gPaused ? '▶' : '⏸';
  pauseBtn.setAttribute('aria-label', gPaused ? 'Davom ettirish' : 'Pauza');
  if (gPaused) {
    clearTimeout(gTimer);
    progressBar.classList.remove('is-animating');
  } else {
    scheduleNext();
  }
});

// barmoq bilan surish
let gTouchX = null;
galleryFrame.addEventListener('touchstart', (e) => { gTouchX = e.touches[0].clientX; }, { passive: true });
galleryFrame.addEventListener('touchend', (e) => {
  if (gTouchX === null) return;
  const dx = e.changedTouches[0].clientX - gTouchX;
  gTouchX = null;
  if (dx < -50) gotoSlide(gIndex + 1);
  if (dx > 50) gotoSlide(gIndex - 1);
});

/* ---------------- 4. Portal (sehrli o'tish) ---------------- */

const portalFlash = $('portal-flash');

function fireFlash(after) {
  if (reduceMotion) { after(); return; }
  portalFlash.classList.add('is-firing');
  setTimeout(() => {
    after();
    setTimeout(() => portalFlash.classList.remove('is-firing'), 500);
  }, 420);
}

$('btn-portal').addEventListener('click', () => {
  clearTimeout(gTimer);
  fireFlash(() => {
    goTo('fantasy');
    startFantasy();
  });
});

/* ---------------- 5. Sehrli olam (fantasy) ---------------- */

const tabsWrap = $('theme-tabs');
const fantasyStage = $('fantasy-stage');
let fIndex = 0;

FANTASY.forEach((theme, i) => {
  const tab = document.createElement('button');
  tab.className = 'theme-tab' + (i === 0 ? ' is-active' : '');
  tab.textContent = theme.label;
  tab.addEventListener('click', () => showTheme(i));
  tabsWrap.appendChild(tab);

  const panel = document.createElement('div');
  panel.className = 'f-panel' + (i === 0 ? ' is-active' : '');
  const h3 = document.createElement('h3');
  h3.textContent = theme.title;
  const p = document.createElement('p');
  p.className = 'f-text';
  p.textContent = theme.text;
  const grid = document.createElement('div');
  grid.className = 'f-grid';
  theme.images.forEach((src) => {
    const card = document.createElement('div');
    card.className = 'f-card';
    const img = document.createElement('img');
    img.src = src;
    img.loading = 'lazy';
    img.alt = theme.title;
    card.appendChild(img);
    grid.appendChild(card);
  });
  panel.append(h3, p, grid);
  fantasyStage.appendChild(panel);
});
const fTabs = [...tabsWrap.children];
const fPanels = [...fantasyStage.children];

function showTheme(i) {
  fIndex = (i + FANTASY.length) % FANTASY.length;
  fTabs.forEach((t, k) => t.classList.toggle('is-active', k === fIndex));
  fPanels.forEach((p, k) => p.classList.toggle('is-active', k === fIndex));
}
function startFantasy() { showTheme(0); }

$('f-prev').addEventListener('click', () => showTheme(fIndex - 1));
$('f-next').addEventListener('click', () => showTheme(fIndex + 1));

$('btn-finale').addEventListener('click', () => {
  fireFlash(() => {
    goTo('final');
    startFinal();
  });
});

/* ---------------- 6. Yakuniy sahna ---------------- */

const finalTextEl = $('final-text');
const finalSign = $('final-sign');
const finalStarsWrap = $('final-stars');
let finalStarted = false;

function buildFinalStars() {
  if (finalStarsWrap.children.length) return;
  for (let i = 0; i < 40; i++) {
    const s = document.createElement('i');
    s.style.left = Math.random() * 100 + '%';
    s.style.top = Math.random() * 100 + '%';
    s.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
    finalStarsWrap.appendChild(s);
  }
}

async function typeFinal() {
  finalTextEl.innerHTML = '';
  finalSign.classList.remove('is-shown');
  for (const line of FINAL_LINES) {
    const span = document.createElement('span');
    span.className = 'final-line';
    span.textContent = line;
    finalTextEl.appendChild(span);
    await new Promise((r) => setTimeout(r, reduceMotion ? 0 : 450));
    span.classList.add('is-shown');
  }
  await new Promise((r) => setTimeout(r, 400));
  finalSign.classList.add('is-shown');
}

function startFinal() {
  buildFinalStars();
  typeFinal();
  finalStarted = true;
}

$('btn-replay').addEventListener('click', () => {
  // hammasini boshidan boshlash
  video.pause();
  gStarted = false;
  clearTimeout(gTimer);
  gPaused = false;
  pauseBtn.textContent = '⏸';
  showTheme(0);
  goTo('intro');
});
